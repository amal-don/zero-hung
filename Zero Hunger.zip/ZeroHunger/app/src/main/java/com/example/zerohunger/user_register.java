package com.example.zerohunger;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.UserHandle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class user_register extends AppCompatActivity {
    EditText name,email,phone,password,confirm;
    String sname,semail,sphone,spassword;
    Button register;
    DatabaseReference databaseReference,reference;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);
        name=(EditText)findViewById(R.id.name);
        email=(EditText)findViewById(R.id.email);
        phone=(EditText)findViewById(R.id.phone);
        password=(EditText)findViewById(R.id.pass);
        confirm=(EditText)findViewById(R.id.confirm);
        register=(Button) findViewById(R.id.register);
        user=new User();
        reference=FirebaseDatabase.getInstance().getReference().child("User");

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                sname=name.getText().toString();
                semail=email.getText().toString();
                spassword=password.getText().toString();
                sphone=phone.getText().toString();
                if (sname.isEmpty())
                {
                    name.setError("name required");
                    name.requestFocus();
                }
                else if (sphone.isEmpty())
                {
                    phone.setError("numer required");
                    phone.requestFocus();

                }
                else if (semail.isEmpty())
                {
                    email.setError("email required");
                    email.requestFocus();

                }
                else if (spassword.isEmpty())
                {
                    password.setError("password required");
                    password.requestFocus();
                }
                else
                {
                    databaseReference= FirebaseDatabase.getInstance().getReference().child("User").child(sphone);

                  final Query query=databaseReference.orderByChild("phone number").equalTo(sphone);
                  query.addListenerForSingleValueEvent(new ValueEventListener() {
                      @Override
                      public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                          if (dataSnapshot.exists())
                          {
                              phone.setError("number already exists");
                          }
                          else
                          {
                              user.setUser_email(semail);
                              user.setUser_mobile(sphone);
                              user.setUser_name(sname);
                              user.setUser_password(spassword);
                              databaseReference.setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                  @Override
                                  public void onSuccess(Void aVoid) {
                                      Toast.makeText(getApplicationContext(),"registered successfully",Toast.LENGTH_SHORT).show();
                                      name.setText("");
                                      phone.setText("");
                                      email.setText("");
                                      password.setText("");


                                  }
                              });
                          }
                      }

                      @Override
                      public void onCancelled(@NonNull DatabaseError databaseError) {

                      }
                  });


                }
            }


        });

    }




}
